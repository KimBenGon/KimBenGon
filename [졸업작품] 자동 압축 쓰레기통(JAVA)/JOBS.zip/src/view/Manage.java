package view;

import javax.swing.JFrame;
@SuppressWarnings("serial")
public abstract class Manage extends JFrame{
	public Trash_panAb pan[]=new Trash_panAb[50];
}
